var searchData=
[
  ['fahrenheittocelsius_288',['fahrenheitToCelsius',['../IRutils_8cpp.html#a83538e86145850c24b1c824723089502',1,'fahrenheitToCelsius(const float deg):&#160;IRutils.cpp'],['../IRutils_8h.html#a83538e86145850c24b1c824723089502',1,'fahrenheitToCelsius(const float deg):&#160;IRutils.cpp']]],
  ['fan_289',['Fan',['../unionAirwellProtocol.html#a7d38043e982231fb6a331d72f7407c10',1,'AirwellProtocol::Fan()'],['../unionGreeProtocol.html#af6f917228f457a24e70256d7c132289c',1,'GreeProtocol::Fan()'],['../unionHaierProtocol.html#a44e6a58782f4c6d5e532c715e9050b5b',1,'HaierProtocol::Fan()'],['../unionHaierYRW02Protocol.html#a4ecca9653d14ccd283e44f6e385ff36a',1,'HaierYRW02Protocol::Fan()'],['../unionMideaProtocol.html#a04b0f344ec9b7cf2bdbd2c530b409fcb',1,'MideaProtocol::Fan()']]],
  ['fanspeed_290',['fanspeed',['../structstdAc_1_1state__t.html#a28a50c877a0eaa71689ccc3bf9c957d7',1,'stdAc::state_t::fanspeed()'],['../unionVoltasProtocol.html#a7a2326d3ecf316e1a4e0a5db0523cad6',1,'VoltasProtocol::FanSpeed()']]],
  ['fanspeed_5ft_291',['fanspeed_t',['../namespacestdAc.html#a8bb0dbf18fe69f639f4ac0b3ff133383',1,'stdAc']]],
  ['fanspeedtostring_292',['fanspeedToString',['../classIRac.html#ab8d8a1ce5de8970c07c90fb41731e2e6',1,'IRac']]],
  ['filter_293',['filter',['../structstdAc_1_1state__t.html#a41e4b957f9e011ddb32d35bfcd56c0e7',1,'stdAc::state_t']]],
  ['fixchecksum_294',['fixChecksum',['../classIRPanasonicAc.html#aa40bef35000ddf6d14e286b3f2044897',1,'IRPanasonicAc']]],
  ['fixup_295',['fixup',['../classIRGreeAC.html#a5bbdcc83f9d49e32379cd27cad0ba130',1,'IRGreeAC::fixup()'],['../classIRKelvinatorAC.html#a389af589003c39794ae5d4bd572fa485',1,'IRKelvinatorAC::fixup()']]],
  ['flap_5fmode_296',['flap_mode',['../classIRArgoAC.html#abfc383d92ced7d47945cc5ac996e5fc4',1,'IRArgoAC']]],
  ['fr_2dfr_2eh_297',['fr-FR.h',['../fr-FR_8h.html',1,'']]],
  ['fujitsu_298',['fujitsu',['../classIRac.html#a23cf80270562ca28ae1f1da2bbb559e7',1,'IRac']]],
  ['fujitsu_5fac_299',['FUJITSU_AC',['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fadad8cf99a3a8776d644b78313306a2108c',1,'IRremoteESP8266.h']]],
  ['fujitsu_5fac_5fremote_5fmodel_5ft_300',['fujitsu_ac_remote_model_t',['../IRsend_8h.html#a7204e78a1fe37a819c0b66f87a685dc0',1,'IRsend.h']]]
];
