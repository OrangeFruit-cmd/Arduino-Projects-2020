var searchData=
[
  ['magiquest_3742',['magiquest',['../unionmagiquest.html',1,'']]],
  ['match_5fresult_5ft_3743',['match_result_t',['../structmatch__result__t.html',1,'']]],
  ['mideaprotocol_3744',['MideaProtocol',['../unionMideaProtocol.html',1,'']]]
];
